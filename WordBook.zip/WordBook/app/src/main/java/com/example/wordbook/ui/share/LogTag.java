package com.example.wordbook.ui.share;

public class LogTag {
    public final static String wordList = "Fragment word list";
    public final static String wordDetail = "Fragment word detail";
    public final static String wordAdd = "Fragment word add";
    public final static String wordLibrary = "Model WordLibrary";
    public final static String mainActivity = "Activity main";
}
